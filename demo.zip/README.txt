Learning sample archive only.
Contains demo.txt. No executable code.
